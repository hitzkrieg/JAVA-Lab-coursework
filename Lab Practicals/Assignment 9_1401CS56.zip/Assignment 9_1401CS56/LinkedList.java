class Node
    {
        Node next;
        Node prev;
        int item;
        
        Node(int ch, Node n1, Node n2)
        {
            item= ch;
            prev= n1;
            next= n2;
        }
        
        
    }

class LinkedList
{
    
    
    Node head;
    Node tail;
    int size;
    
    LinkedList()
    {
        head=null;
        tail=null;
        size=0;
    }
    
    void addAtEnd(int ch)
    {
        if(tail==null)
        {
            tail=head=new Node(ch, null, null);
            size++;
        }
        else
        {
            Node temp= new Node(ch,tail,null);
            tail.next= temp;
            tail= temp;
            size++;
            
        }
        
    }
    
    boolean removeEnd()
    {   if(tail==null)
        {
            System.out.println("Cannot remove more");
            return(false);
        }
        else if(head==tail)
        {
            head=null;
            tail=null;
            size--;
            return(true);
            
        }
        else 
        {
            tail= tail.prev;
            tail.next= null;
            size--;
            return(true);
        }
    }
    
    int getLast()
    {
        if(tail==null)
        {   
            System.out.println("Invalid operation");
            return(-1);
        }
        else
        {
            return(tail.item);
        }
    }
    
    void swap(Node i, Node j) 
    {
        int temp= i.item;
                 i.item= j.item;
                 j.item= temp;
            
    }
    
    void printList()
    {
        System.out.println("\n Printing List: ");
        Node temp= head;
        while(temp!= null)
        {
            System.out.print(temp.item + " ");
            temp= temp.next;
        }
    }
            
        
        
    
                
            
}


class MergeSort
{
    static int comparisons;
    static int merges;
  
    static void sort(LinkedList A)
    {
        comparisons=0; merges=0;
        mergeSort(A,1, A.size );
        System.out.println("\n \n \n Sorted by Merge Sort.Comparisons= " + comparisons + " Merges= " + merges);
    }
    
    static void mergeSort(LinkedList A, int p, int q)
    {
        if(p<q)
        {
            int r= (p+q)/2;
            mergeSort(A, p, r);
            mergeSort(A, r+1, q);
            merges++;
            merge(A, p, q, r);
        }
        
    }
    
    static void merge(LinkedList A, int p, int q, int r)
    {
        Node n1= A.head;
        for(int i=1; i<p; i++)
        {
            n1= n1.next;
        }
        /*Now n1 contains pth element*/
        Node n2= A.head;
        for(int i=1; i<r+1; i++)
        {
            n2= n2.next;
        }
        /*Now n2 contains r+1 th element*/
        
        Node temp= n1;
        LinkedList l1= new LinkedList();
        LinkedList l2= new LinkedList();
        
            for(int i=1; i<=r-p+1; i++)
            {
                l1.addAtEnd(temp.item);
                temp= temp.next;
            }
            
            l1.addAtEnd(100000);
            temp= n2;
            for(int i=1; i<=q-r; i++)
            {
                l2.addAtEnd(temp.item);
                temp= temp.next;
            }
            l2.addAtEnd(100000);
            Node temp1= l1.head;
            Node temp2= l2.head;
            
            temp= n1;
            
            for(int k=p; k<= q; k++)
            {
                comparisons++;
                if(temp1.item < temp2.item)
                {
                    temp.item= temp1.item;
                    temp1= temp1.next;
                    temp= temp.next;
                }
                else
                {
                    temp.item= temp2.item;
                    temp2= temp2.next;
                    temp= temp.next;
                }
            }
            
                
        
        
    }
    
}

class QuickSort
{
    static int swaps;
    static int comparisons;
    static void sort(LinkedList A)
    {
        swaps=0;
        comparisons=0;
        quickSort(A, 1, A.size);
        System.out.println("\n \n \n Sorted by Quick Sort. Swaps: " + swaps + " Comparisons: " + comparisons);
    }
    
    static void quickSort(LinkedList A, int low, int high)
    {
        if(low<high)
        {
            int p = partition(A, low, high);
            quickSort(A, low, p - 1);
            quickSort(A, p + 1, high);
        }
    }
     static int partition(LinkedList A, int low, int high)
     {
         Node pivot = A.head;
         for(int k= 1; k<high; k++)
         {
             pivot= pivot.next;
         }
         Node i= A.head;
         for(int k= 1; k<low; k++)
         {
             i= i.next;
         }
         Node j=i; int i1= low; 
         while(j!= pivot)
         {
             comparisons++;
             if(j.item< pivot.item)
             {
                 A.swap(i,j);
                 swaps++;
                 i= i.next;
                 i1++;
             }
             j= j.next;
         }
         A.swap(i, pivot);
         swaps++;
         return(i1);
         
         
         
         
     }
    
}

