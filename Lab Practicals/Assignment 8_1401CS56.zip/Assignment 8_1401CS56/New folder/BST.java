import java.util.*;

/*May have to alter the functions if dupilcate keys/data are present */
/* Place the file of Queue in the same folder*/

public class BST
{
    private class Queue<T>
    {
    ArrayList<T> queue= new ArrayList();
    int size;
    
    Queue()
    {
        size=0;
    }
    
    void enqueue(T item)
    {
        queue.add(item);
        size++;
    }
    
    T dequeue()
    {
        T temp;
      if(queue.isEmpty()== true)
          return(null);
      else
      {
          temp = queue.get(0);
          queue.remove(0);
                  
          size--;
          return(temp);
      }
      
    }
    
    }
    private class Node
    {
        int data;
        Node left;
        Node right;
        Node parent;
        
        Node(int data)
        {
            this.data= data;
            left= null;
            right= null;
            parent= null;
        }
    }
    
    Node root;
    int size;
    int count;
    int count1;
    
    BST()
            {
                root= null;
                size=0;
                count=0;
                count1=0;
            }
    
    
    void insert(int item)
    {   
        Node temp= new Node(item);
        addNode(root, temp);
    }
    
    void addNode(Node n, Node item) 
    {
        if(n==null)
        {
          root= item;
          size++;  
        }    
        else if(n.data> item.data)
        {
            if(n.left==null)
            {
                n.left= item;
                size++;
            }
            else
            {
            addNode(n.left, item);
            }
        }    
        else
        {
            if(n.right==null)
            {
                n.right= item;
                size++;
            }
            else
            {
            addNode(n.right, item);
            }
        }    
       
    }
    
    boolean search(int item) 
    {
        count=0;
        Node R= find(root, item);
        if(R==null)
        {
            System.out.println("Not found!");
            System.out.println("Count: "+ count);
            return(false);
        }
        else 
        {
            System.out.println("Found!");
            System.out.println("Count: "+ count);
            return(true);
        }
                
    }
    
    Node find(Node n, int item)
    {
        if(n!= null)
        {
            count++;
            
        }
        if(n==null)
            return(null);
        
        else if(item== n.data)
        {
            return(n);
        }
        else if(item < n.data)
            return(find(n.left, item));
        else if(item > n.data)
            return(find(n.right, item));
        
        return(null);
        
    }
    
    void levelOrder()
    {
        Queue<Node> q1= new Queue<Node>();
        if(root!=null)
        {
            q1.enqueue(root);
        }
        
        while(q1.size!=0)
        {
            
            Node s= q1.dequeue();
            System.out.println(s.data);
            if(s.left!=null)
                q1.enqueue(s.left);
            if(s.right!=null)
                q1.enqueue(s.right);
          
        }
        
        
    }
    
     
    void minimumNumbers()
    {
        count=0;
        count1=0;
        inOrder(root);
        System.out.println("Count= "+ count1);
    }
                
            
    void inOrder(Node n) 
    {
      if(count1<10)
      {
        count1++;
        if(n==null)
            return;
        
        if(n.left!=null)
        {
            
            inOrder(n.left);
        }
        
        if(n!=null)
        {
            count++;
            System.out.print(n.data + " ");
        }
        
        if(n.right!=null)
        {
           
            inOrder(n.right);
        }
      }  
    }
    
    
}
