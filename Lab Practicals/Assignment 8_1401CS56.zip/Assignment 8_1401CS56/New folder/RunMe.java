import java.util.Scanner;
import java.io.*;
class RunMe
{
    public static void main(String[] args)
    {
        Heap h1= new Heap();
        BST b1= new BST();
        Scanner sc= null;
        try
        {
            sc= new Scanner(new File("ABC.txt"));
        }
        catch(Exception e)
                {
                   System.out.println("Error in file reading");
                }
        Scanner stdIn= new Scanner(System.in);
        int a;
        for(int i=0; i<100; i++)
        {
            a= sc.nextInt();
            h1.insert(a);
            b1.insert(a);
            
        }
        System.out.println("*************************************************************");
        System.out.println("Searching: \n");
        System.out.println("Enter a number to be searched: ");
        int search= stdIn.nextInt();
        System.out.println("Searching by BST: ");
        b1.search(search);
        
        System.out.println("\n Searching in a Heap: ");
        h1.search(search);
        
        System.out.println("*************************************************************");
        System.out.println("Finding 10 minimum numbers: \n");
        System.out.println("\n Using BST:");
        b1.minimumNumbers();
         System.out.println("\n Using Heap:");
         int count=0;
        for(int i=0; i<10; i++)
        {
          System.out.print(h1.extract_min()+ " ");
          count++;
        }
        System.out.println("Count: "+ count);
        System.out.println("*************************************************************");
        
        
        
        
       
        
        
    }
            
    
}