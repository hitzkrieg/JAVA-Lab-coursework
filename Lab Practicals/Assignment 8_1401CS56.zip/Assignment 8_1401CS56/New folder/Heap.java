import java.util.ArrayList;

public class Heap
{
    private class Queue<T>
    {
    ArrayList<T> queue= new ArrayList();
    int size;
    
    Queue()
    {
        size=0;
    }
    
    void enqueue(T item)
    {
        queue.add(item);
        size++;
    }
    
    T dequeue()
    {
        T temp;
      if(queue.isEmpty()== true)
          return(null);
      else
      {
          temp = queue.get(0);
          queue.remove(0);
                  
          size--;
          return(temp);
      }
      
    }
    
    }
    
    private class Node
    {
       Node left;
       Node right;
       Node parent;
       int data;
        
       
       Node(int data, Node parent)
       {
           this.data= data;
           this.parent= parent;
           this.left= null;
           this.right= null;
       }
       
       
    }

    Node head;
    int size;
    int count;
    

    Heap()
    {
        head= null;
        size= 0;
        count=0;
        
    }
    
    Node findPos()/*To be written*/
    {
        Queue<Node> q1=new Queue();
        if(head!=null)
        {
            q1.enqueue(head);
        }
        Node s= null;
        while(q1.size!=0)
        {
            s= q1.dequeue();
            if((s.left==null)|| (s.right==null))
            {
                return s;
            }
            if(s.left!=null)
                q1.enqueue(s.left);
            if(s.right!=null)
                q1.enqueue(s.right);
            
        }
        return null;
    }

    void levelOrder()
    {
        System.out.println("Printing level wise: \n");
        Queue<Node> q1= new Queue();
        if(head!=null)
        {
            q1.enqueue(head);
        }
        
        while(q1.size!=0)
        {
            
            Node s= q1.dequeue();
            System.out.print(s.data + " ");
            if(s.left!=null)
                q1.enqueue(s.left);
            if(s.right!=null)
                q1.enqueue(s.right);
          
        }
        
        
    }
    void insert(int n)
    {
        if(head==null)
        {
            head= new Node(n, null);
            size++;
        }
        else
        {
            Node pos= findPos();
            if(pos.left== null)
            {
                pos.left= new Node(n, pos);
                size++;
                bubbleUp(pos.left);
            }
            else 
            {
                pos.right= new Node(n, pos);
                size++;
                bubbleUp(pos.right);
            }
            
        }
    }
    void swap(Node a, Node b)
    {
        int temp= b.data;
            b.data= a.data;
            a.data= temp;
    }
    void bubbleUp(Node a) 
    {
        
        if(a.parent!= null)
        {
            if(a.parent.data >a.data)
            {
                swap(a.parent, a);
                bubbleUp(a.parent);
            }
        }
    }        
    
    void bubbleDown(Node b)
    {
        if(b.left==null)
            return;
        else if(b.right== null)
        {
            if(b.data>b.left.data)
            {
            swap(b, b.left);
            bubbleDown(b.left);
                
            }
        }
        else
        {
            Node temp= b.left;
            if(b.left.data>b.right.data)
                temp= b.right;
            if(b.data>temp.data)
            {
                swap(b,temp);
                bubbleDown(temp);
            }
                        
        }
            
    }
    
    int min()
    {
        if(head!=null)
        return(head.data);
        else
        {
            System.out.println("Empty heap");
            return(-1);
        }
            
    }
    
    Node rightMost() /*To be changed*/
    {
        Queue<Node> q1=new Queue();
        if(head!= null)
        {
            q1.enqueue(head);
        }
        Node s= null;
        while(q1.size!=0)
        {
            s= q1.dequeue();
             if(s.left!=null)
                q1.enqueue(s.left);
            if(s.right!=null)
                q1.enqueue(s.right);
            if((s.left==null)|| (s.right==null))
            {
                break;
            }
           
        }    
        if(q1.size==0)
        {
            return(s);
        }
        else
        {
            while(q1.size!=1)
                q1.dequeue();
            return(q1.dequeue());
        }
            
    }
        
        
        
    
    
    int extract_min() /*Same as delete*/
    {
        if(head==null)
        {
            System.out.println("Empty heap");
            return(-1);
        }
        else if(head.left== null)
        {
            int temp= head.data;
            head= null;
            size--;
            return(temp);
        }
        else
        {
            Node rightmost= rightMost();
            int minimum= head.data;
            head.data= rightmost.data;
            if(rightmost== rightmost.parent.left)
                rightmost.parent.left= null;
            else
                rightmost.parent.right= null;
            size--;
            bubbleDown(head);
            return(minimum);
           
        }
            
       
    }
    void search(int n)
    {      
        count= 0;
            
            Node k= inOrder(head, n);
            if(k== null)
            {
                System.out.println("Not found!");
                System.out.println("Count: "+ count);
            }
            else 
            {
                System.out.println("Found!");
            }
    }
    Node inOrder(Node s, int n)
    {
        if(s== null)
        {
            System.out.println("Empty Heap");
            
            
        }
        else
        {   Node k1, k2;
        
            if(s.left!=null)
            {
               k1= inOrder(s.left, n);
               if(k1!= null)
                   return(k1);
            }   
            
            
            
            if(s.data== n)
            {
                count++;
                System.out.println("Found");
                System.out.println("Count: "+ count);
                return(s);
                
            }
            
            else
            {
                count++;
                
            }
            
                
        
            if(s.right!=null)
            {
               k2= inOrder(s.right, n);
               if(k2!= null)
               return(k2);
            }   
            
                
            }
        return(null);
    }

}

