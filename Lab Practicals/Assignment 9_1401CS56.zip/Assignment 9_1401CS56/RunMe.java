import java.util.Scanner;
import java.io.*;

class RunMe
{
    public static void main(String[] args)
    {
        LinkedList l= new LinkedList();
        LinkedList m= new LinkedList();
        Scanner sc= null;
        
        try
        {
            sc= new Scanner(new File("data.txt"));
        }
        catch(Exception e)
                {
                   System.out.println("Error in file reading");
                }
        
        while(sc.hasNext())
        {
            int tmp= sc.nextInt();
            l.addAtEnd(tmp);
            m.addAtEnd(tmp);
        }
        
	System.out.println("Original list: ");
	 l.printList();
	System.out.println("\n ****************************************************");

        MergeSort.sort(l);
        l.printList();
        System.out.println("\n ****************************************************");
        
        QuickSort.sort(m);
        m.printList();System.out.println("\n ****************************************************");
    }
    
}